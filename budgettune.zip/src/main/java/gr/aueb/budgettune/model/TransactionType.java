package gr.aueb.budgettune.model;

public enum TransactionType {
    INCOME,    // Έσοδο
    EXPENSE    // Έξοδο
}
