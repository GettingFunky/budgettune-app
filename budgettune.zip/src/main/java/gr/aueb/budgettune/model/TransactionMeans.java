package gr.aueb.budgettune.model;

public enum TransactionMeans {
    CASH,    // Μετρητά
    CARD,    // Κάρτα
    OTHER    // Άλλος Τρόπος
}
