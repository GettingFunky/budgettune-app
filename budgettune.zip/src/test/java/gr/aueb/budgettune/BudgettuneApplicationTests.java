package gr.aueb.budgettune;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BudgettuneApplicationTests {

	@Test
	void contextLoads() {
	}

}
